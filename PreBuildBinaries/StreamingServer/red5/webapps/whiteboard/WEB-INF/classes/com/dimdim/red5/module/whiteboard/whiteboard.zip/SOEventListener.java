/*
 **************************************************************************
 *                                                                        *
 *               DDDDD   iii             DDDDD   iii                      *
 *               DD  DD      mm mm mmmm  DD  DD      mm mm mmmm           *
 *               DD   DD iii mmm  mm  mm DD   DD iii mmm  mm  mm          *
 *               DD   DD iii mmm  mm  mm DD   DD iii mmm  mm  mm          *
 *               DDDDDD  iii mmm  mm  mm DDDDDD  iii mmm  mm  mm          *
 *                                                                        *
 **************************************************************************
 **************************************************************************
 *                                                                        *
 * Part of the DimDim V 2.0 Codebase (http://www.dimdim.com)	          *
 *                                                                        *
 * Copyright (c) 2008 Dimdim Inc. All Rights Reserved.                 	  *
 *                                                                        *
 *                                                                        *
 * This code is licensed under the Dimdim License                         *
 * For details please 									                  *
 * 	visit http://www.dimdim.com/opensource/dimdim_license.html			  *
 *                                                                        *
 **************************************************************************
 */

package com.dimdim.red5.module.whiteboard;

/**
 * @author Rajesh Dharmalingam
 * @email rajesh@dimdim.com
 *
 */


//import java.util.List;
//import java.util.Map;
//import org.red5.server.api.IAttributeStore;
//import org.red5.server.api.so.ISharedObject;
//import org.red5.server.api.so.ISharedObjectBase;
//import org.red5.server.api.so.ISharedObjectListener;


public class SOEventListener //implements ISharedObjectListener 
{	
/*

	public void onSharedObjectConnect(ISharedObjectBase so)
	{
//		System.out.println("########### shared object connect called ###########");
	}


	public void onSharedObjectDisconnect(ISharedObjectBase so)
	{
//		System.out.println("########### shared object disconnect called ###########");
	}

	
	public void onSharedObjectUpdate(ISharedObject so, String key, Object value) 
	{
//		System.out.println("########### shared object update called ###########");
//		System.out.println("---------->"+so.toString() +"| Key:"+key+", Value:"+value);		
		
	}

	
	public void onSharedObjectUpdate(ISharedObjectBase so, IAttributeStore values)
	{
//		System.out.println("########### shared object update called ###########");
//		System.out.println("---------->"+so.toString() +", Value:"+values);
	}
	

	public void onSharedObjectUpdate(ISharedObjectBase so, String key, Object value)
	{
		//The attribute <key> of the shared object <so>
		// was changed to <value>.
//		System.out.println("########### shared object update called ###########");

	}
	
	
	public void onSharedObjectUpdate(ISharedObjectBase so, Map values)
	{
//		System.out.println("########### shared object update called ###########");
		
	}


	public void onSharedObjectDelete(ISharedObjectBase so, String key)
	{
//		System.out.println("########### shared object delete called ###########");
	}


	public void onSharedObjectClear(ISharedObjectBase so)
	{
//		System.out.println("########### shared object clear called ###########");
	}


	public void onSharedObjectSend(ISharedObjectBase so, String method, List params)
	{
//		System.out.println("########### shared object send called ###########");	
	}
	*/
}