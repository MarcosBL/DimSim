/*
 **************************************************************************
 *                                                                        *
 *               DDDDD   iii             DDDDD   iii                      *
 *               DD  DD      mm mm mmmm  DD  DD      mm mm mmmm           *
 *               DD   DD iii mmm  mm  mm DD   DD iii mmm  mm  mm          *
 *               DD   DD iii mmm  mm  mm DD   DD iii mmm  mm  mm          *
 *               DDDDDD  iii mmm  mm  mm DDDDDD  iii mmm  mm  mm          *
 *                                                                        *
 **************************************************************************
 **************************************************************************
 *                                                                        *
 * Part of the DimDim V 2.0 Codebase (http://www.dimdim.com)	          *
 *                                                                        *
 * Copyright (c) 2008 Dimdim Inc. All Rights Reserved.                 	  *
 *                                                                        *
 *                                                                        *
 * This code is licensed under the Dimdim License                         *
 * For details please 									                  *
 * 	visit http://www.dimdim.com/opensource/dimdim_license.html			  *
 *                                                                        *
 **************************************************************************
 */


package com.dimdim.red5.module.whiteboard;

/**
 * @author Rajesh Dharmalingam
 * @email rajesh@dimdim.com
 *
 */


//import java.util.HashMap;
//import org.red5.server.api.IScope;
//import org.red5.server.api.so.ISharedObject;

public class MeetingWhiteboard {
/*
	protected String prefix;
	protected String name;
	protected boolean isPersistent;
	protected ISharedObject cache;
	protected IScope appScope;
	protected WhiteboardPages pages;
	protected WhiteboardPage currentPage;
	protected int currentPageIndex;
	protected Whiteboard whiteboardApp;
	protected HashMap whiteboards;
	
	private MeetingWhiteboard(Whiteboard whiteboardApp){
		this.whiteboardApp = whiteboardApp;
	}

	private MeetingWhiteboard(IScope scope, boolean isPersitent,
			Whiteboard whiteboardApp, HashMap whiteboards) {
		
	}
	
	private String getName() {
		return this.name;
	}
*/
}
